/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _XT_CONNMARK_H_target
#define _XT_CONNMARK_H_target

#include <linux/netfilter/xt_connmark.h>

#endif /*_XT_CONNMARK_H_target*/
